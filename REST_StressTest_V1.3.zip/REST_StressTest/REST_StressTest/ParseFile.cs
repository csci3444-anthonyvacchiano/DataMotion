﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_StressTest
{
    class ParseFile
    {
        public static void ReadFromFile(string FileName)
        {
            Application xlsApp = new Application();

            Workbook wb = xlsApp.Workbooks.Open(FileName);
            Sheets sheets = wb.Worksheets;
            Worksheet ws = (Worksheet)sheets.get_Item(1);

            List<string[]> Arrays = new List<string[]>();

            int ArrayCount = 1;
            Range Username = ws.UsedRange.Columns[ArrayCount];
            Array UserNames = (Array)Username.Cells.Value;
            string[] UserNameArray = UserNames.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(UserNameArray);
            Credentials.UserName = UserNameArray;

            ArrayCount++; // is 2
            Range Password = ws.UsedRange.Columns[ArrayCount];
            Array Passwords = (Array)Password.Cells.Value;
            string[] PasswordArray = Password.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(PasswordArray);
            Credentials.Password = PasswordArray;

            ArrayCount++; // is 3
            Range SendPull = ws.UsedRange.Columns[ArrayCount];
            Array SendorPull = (Array)SendPull.Cells.Value;
            string[] SendorPullArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(SendorPullArray);
            Attributes.SendPull = SendorPullArray;

            //
            ArrayCount++; // is 4
            Range NumMessage = ws.UsedRange.Columns[ArrayCount];
            Array NumberMessage = (Array)SendPull.Cells.Value;
            string[] NumMessArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(NumMessArray);
            Attributes.numMess = NumMessArray;

            ArrayCount++; // is 5
            Range To = ws.UsedRange.Columns[ArrayCount];
            Array ToPerson = (Array)SendPull.Cells.Value;
            string[] ToArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(ToArray);
            Attributes.To = ToArray;

            ArrayCount++; // is 6
            Range Subject = ws.UsedRange.Columns[ArrayCount];
            Array Subjects = (Array)SendPull.Cells.Value;
            string[] SubjectArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(UserNameArray);
            Attributes.Subject = SubjectArray;

            ArrayCount++; // is 7
            Range Body = ws.UsedRange.Columns[ArrayCount];
            Array Bodies = (Array)SendPull.Cells.Value;
            string[] BodyArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(BodyArray);
            Attributes.Body = BodyArray;

            ArrayCount++; // is 8
            Range Payload = ws.UsedRange.Columns[ArrayCount];
            Array PayloadSize = (Array)SendPull.Cells.Value;
            string[] PayLoadSizeArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(PayLoadSizeArray);
            Attributes.PayLoad = PayLoadSizeArray;

            ArrayCount++; // is 9
            Range Duration = ws.UsedRange.Columns[ArrayCount];
            Array Durations = (Array)SendPull.Cells.Value;
            string[] DurationArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(DurationArray);
            Attributes.Duration = DurationArray;

            ArrayCount++; // is 10
            Range Folder = ws.UsedRange.Columns[ArrayCount];
            Array Folders = (Array)SendPull.Cells.Value;
            string[] FolderArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(FolderArray);
            Attributes.Folder = FolderArray;

            foreach (string[] array in Arrays)
            {
                if (array.Length != UserNameArray.Length)
                {
                    Console.Write("Please make sure all fields are filled out." + Environment.NewLine);
                    string filename = Console.ReadLine();
                    ReadFromFile(filename);
                }
                else
                {
                    for (int i = 1; i < ArrayCount; i++)
                    {
                      // Console.WriteLine(SendPull[i].Cells.Value); // [i] error
                     //  Console.WriteLine(ws.UsedRange.Columns[i]);
                      //  Console.WriteLine(Arrays[i]);
                       //  Console.WriteLine(FolderArray); // [i] error
                       // Console.WriteLine();
                    }
                }



                // create array for the columns, change columns to match the excel columns, update column number
            }
        }
    }
}
