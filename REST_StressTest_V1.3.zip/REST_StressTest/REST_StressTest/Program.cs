﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REST_StressTest
{
    class Program
    {
        [STAThread]
        static void Main() ///(string[] args)
        {
            // creates output stating the dirrections
            Console.WriteLine("Welcome the the REST stress test.");
            Console.WriteLine("Please enter the template file.");
            // creates fileLocation using the user's input

            string fileLocation = Console.ReadLine();

            Credentials main = new Credentials();
          /// FIX    main(fileLocation); //FIX


             Console.WriteLine("Logon succesful");

            ParseFile.ReadFromFile(fileLocation);


            for (int i = 0; i < Credentials.UserName.Length; i++) // error, FIX 
            {
                LogOn.getSessionKeys(Credentials.UserName[i], Credentials.Password[i]);
            }
            // make logon succesful, make sure passowrd and username does work


            //  ParseFile main1 = new ParseFile();
            // main1.ReadFromFile(fileLocation);

            Console.WriteLine("Loading...");

            Console.Read();
            //Display message asking for file.
            //Pull file in

            //Next steps parse file


        }
    }
}
