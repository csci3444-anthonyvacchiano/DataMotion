﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_StressTest
{
    class Credentials
    {
        public static string[] UserName { get; set; }
        public static string[] Password { get; set; }
    }
}
