﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_StressTest
{
    class Attributes
    {
        public static string[] SendPull { get; set; }
        public static string[] numMess { get; set; }
        public static string[] To { get; set; }
        public static string[] Subject { get; set; }
        public static string[] Body { get; set; }
        public static string[] PayLoad { get; set; }
        public static string[] Duration { get; set; }
        public static string[] Folder { get; set; }
    }
}
