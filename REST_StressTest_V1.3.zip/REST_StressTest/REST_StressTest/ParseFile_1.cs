﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_StressTest
{
    class ParseFile
    {
        public static void ReadFromFile(string FileName)
        {
            Application xlsApp = new Application();

            Workbook wb = xlsApp.Workbooks.Open(FileName);
            Sheets sheets = wb.Worksheets;
            Worksheet ws = (Worksheet)sheets.get_Item(1);

            List<string[]> Arrays = new List<string[]>();

            //UserName
            Range UsernameCol = ws.UsedRange.Columns[1];
            Array UserNames = (Array)UsernameCol.Cells.Value;
            string[] UserNameArray = UserNames.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(UserNameArray);
            Credentials.UserName = UserNameArray;

            //Password
            Range PasswordCol = ws.UsedRange.Columns[2];
            Array Passwords = (Array)PasswordCol.Cells.Value;
            string[] PasswordArray = Passwords.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(PasswordArray);
            Credentials.Password = PasswordArray;

            //Function
            Range SendPullCol = ws.UsedRange.Columns[3];
            Array SendorPull = (Array)SendPullCol.Cells.Value;
            string[] SendorPullArray = SendorPull.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(SendorPullArray);
            Attributes.SendPull = SendorPullArray;

            //Number of Messages
            Range MessNumCol = ws.UsedRange.Columns[4];
            Array NumMess = (Array)MessNumCol.Cells.Value;
            string[] NumMessArray = NumMess.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(NumMessArray);
            Attributes.numMess = NumMessArray;

            //To Feild
            Range ToCol = ws.UsedRange.Columns[5];
            Array To = (Array)ToCol.Cells.Value;
            string[] ToArray = To.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(ToArray);
            Attributes.To= ToArray;

            //Subject Feild
            Range SubjectCol = ws.UsedRange.Columns[6];
            Array Subject = (Array)SubjectCol.Cells.Value;
            string[] SubjectArray = Subject.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(UserNameArray);
            Attributes.Subject = SubjectArray;

            //Body Feild
            Range BodyCol = ws.UsedRange.Columns[7];
            Array Body = (Array)SendPullCol.Cells.Value;
            string[] BodyArray = Body.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(BodyArray);
            Attributes.Body = BodyArray;

            //Pay Load Size
            Range PayLoadSizeCol = ws.UsedRange.Columns[8];
            Array PayLoadSize = (Array)PayLoadSizeCol.Cells.Value;
            string[] PayLoadSizeArray = PayLoadSize.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(PayLoadSizeArray);
            Attributes.PayLoad = PayLoadSizeArray;

            //Duration
            Range DurationCol = ws.UsedRange.Columns[9];
            Array Duration = (Array)DurationCol.Cells.Value;
            string[] DurationArray = Duration.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(DurationArray);
            Attributes.Duration = DurationArray;

            //Folder
            Range FolderCol = ws.UsedRange.Columns[10];
            Array Folder = (Array)FolderCol.Cells.Value;
            string[] FolderArray = Folder.OfType<object>().Select(o => o.ToString()).ToArray();
            Arrays.Add(FolderArray);
            Attributes.Folder = FolderArray;

            //Check List Size
            foreach (string[] array in Arrays)
            {
                if (array.Length != UserNameArray.Length)
                {
                    Console.Write("Please make sure all feilds are filled out." + Environment.NewLine);
                    string filename = Console.ReadLine();
                    ReadFromFile(filename);
                }
            }
        }
    }
}
