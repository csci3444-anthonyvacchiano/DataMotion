﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REST_StressTest
{
    class Program
    {
        [STAThread]
        static void Main() ///(string[] args)
        {
            //Send Directions
            Console.WriteLine("Welcome the the REST stress test.");
            Console.WriteLine("Please enter the template file.");

            //Read File Name
            string fileLocation = Console.ReadLine();

            //Parse File Information
            ParseFile.ReadFromFile(fileLocation);

            //Get Session Keys
            for(int i = 1; i < Credentials.UserName.Length; i++)
            {
                LogOn.getSessionKeys(Credentials.UserName[i], Credentials.Password[i]);
            }

            //Run Functions?

            Console.Read();
        }
    }
}
