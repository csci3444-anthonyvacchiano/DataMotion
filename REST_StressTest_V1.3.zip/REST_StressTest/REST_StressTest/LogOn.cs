﻿using System;
using System.Collections.Generic;
using DMWeb_REST;
using Messaging_Library.Models;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_StressTest
{
    class LogOn
    {
        public static void getSessionKeys(string UserName, string password)
        {
            List<string> sesskeys = new List<string>();
            try
            {
                DMWeb dmweb = new DMWeb();

                string sessionkey = dmweb.Account.LogOn(new AccountModels.LogOn { UserIdOrEmail = UserName, Password = password }).GetAwaiter().GetResult();
                sesskeys.Add(sessionkey);
                Console.WriteLine(sessionkey);
            }
            catch
            {
                Console.WriteLine("Sign On Failed.");
            }
        }
    }
}
